import langModel.*;


public class Application_LanguageModels {

	public static void main(String[] args) {
		String sentence1 = "<s> antoine écoute une chanson </s>";
		String sentence2 = "<s> lionel écoute une chanson </s>";


		/* création des vocabulaires */
		
		VocabularyInterface vocab1, vocab2;
		
		//création du premier vocabulaire
		
		
		//création du second vocabulaire
		
		
		
		/* création des modèles de langage */
		
		NgramCountsInterface ngramCounts_bigram_vocab1, ngramCounts_bigram_vocab2;
		LanguageModelInterface lm_bigram_vocab1, lm_bigram_laplace_vocab1, lm_bigram_vocab2, lm_bigram_laplace_vocab2;
		
		//création du modèle de langage sans lissage, avec le premier vocabulaire
		
		
		//création du modèle de langage avec lissage, avec le premier vocabulaire
		
		
		//création du modèle de langage sans lissage, avec le second vocabulaire
				
		
		//création du modèle de langage avec lissage, avec le second vocabulaire
		
		
		
		/* utilisation des modèles de langage */
		
		
	}

}
